<launch>
  <!-- Load Gazebo -->
  <include file="$(find gazebo_ros)/launch/empty_world.launch"/>

  <!-- Spawn robot model -->
  <node name="spawn_urdf" pkg="gazebo_ros" type="spawn_model" args="-urdf -model my_robot -param robot_description"/>
</launch>
